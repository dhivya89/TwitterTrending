trending-twitter-topics
=======================

A front-end web app using the MVC javascript framework Ember to display Twitter trending topics and associated tweets